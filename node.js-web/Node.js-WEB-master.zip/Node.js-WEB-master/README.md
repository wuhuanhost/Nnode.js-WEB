#Express+mongoDB+AngularJS+Node.js项目

## 版本列表

`Node.js    v4.2.4`

`Express    v4.13.1`

`MongoDB    v3.2.3`

`Angular.js v1.5.3`

## 项目结构

```
-app
    controllers   控制器
    modules       模型
    schemas       模型
    views         视图
-conf
-logs
-bin
    www   
-doc
    readme.md
-lib
    angular
    jquery
    bootstrap
-public
    css
    js
    images
    dist
-webapp
    css
    js
    images
    dist
-routes
    index.js
    users.js
```

## 运行项目

1. 启动MongoDB
2. 启动node服务器